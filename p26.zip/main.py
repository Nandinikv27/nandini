a=input()
s=input()
total=0
for i in a:
    if i not in s:
        distance=9999
        for j in s:
            temp=abs(ord(i)-ord(j))
            if temp < distance:
                distance=temp
        total+=distance
print(total)