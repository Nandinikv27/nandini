def dog_age_in_human_years(N):
    return N * 7
N=int(input())
print(dog_age_in_human_years(N))